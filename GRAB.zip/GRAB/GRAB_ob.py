import os
import csv
import math
import numpy as np
import pickle
import copy
import networkx as nx

from sklearn.metrics import pairwise

import torch
from torch import nn
from torch.nn import Linear, ReLU, Module
from torch.nn import functional as F
from torch_geometric.data import Data
from torch_geometric.utils import coalesce, dense_to_sparse

from GRAB.graph import Graph
from GRAB.networks import LBP, GCN
from GRAB.utils import init_weights, seed_everything, generate_index_set, to_LBP_graph, get_loss, knn_network, calculate_new_prior
from GRAB.metrics import Metrics as Metrics

def GRAB(input_features,
         negative_range, 
         positive_range,
         knn_num,
         space_name,
         save_dir,
         seed_num=73,
         gpu=1,
         save_embedding=True):
    print(f'======= Start training: {space_name}_{seed_num} =======')
    ## Set device
    device = torch.device('cuda:'+str(gpu) if torch.cuda.is_available() else 'cpu')

    input_features = input_features.to(device)
    input_shape = input_features.size(1)
    
    # Get initial index set
    index_set = generate_index_set(seed_num, negative_range, positive_range)
    
    # Initial node index
    train_p_idx = index_set[0]
    train_u_idx = index_set[1]
    val_p_idx = index_set[2]
    val_n_idx = index_set[3]
    test_p_idx = index_set[4]
    test_n_idx = index_set[5]
    
    # Generate knn-network and LBP graph
    data = knn_network(input_features, knn_num, space_name, save_dir, seed_num)
    lbp_graph = to_LBP_graph(data, device)
    data = data.to(device)
    print('========= LBP Graph generated =========')
    
    lbp = LBP(lbp_graph, train_p_idx, num_states=2, device=device)
    GCN_model = GCN(input_shape, device).to(device)
    GCN_model.apply(init_weights)
    
    optimizer = torch.optim.Adam(GCN_model.parameters(), lr=0.01, weight_decay=5e-3)
    
    ## Set learning hyperparameters
    EPSILON = 1e-10
    THRESHOLD = 1e-6
    GCN_epoches = 100
    
    train_count = 0
    old_loss = 1000001.0
    new_loss = 1000000.0
    
    train_prior_list = []
    
    seed_everything(seed=seed_num)
    
    print(f'========= Start GRAB training =========')
    
    while new_loss - old_loss < 0 or train_count == 0:
        seed_everything(seed=seed_num)
        old_loss = new_loss
        if train_count == 0:
            prior = 0
        beliefs = lbp(prior, THRESHOLD, EPSILON)
        new_loss = train(GCN_model, data, beliefs, train_p_idx, train_u_idx, 100, optimizer, device, prior)
        prior = calculate_new_prior(GCN_model, data, train_u_idx)   
        log = 'Epoch: {:03d}, prior: {:.2f}, old loss: {:.4f}, new loss: {:.4f}'
        print(log.format(train_count, prior, old_loss, new_loss))
        train_count += 1

    gcn_save_dir = '/data/project/joebrother/pu_learning/Results/'+save_dir+'/GRAB/GCN/'
    belief_save_dir = '/data/project/joebrother/pu_learning/Results/'+save_dir+'/GRAB/belief/'
    
    isExist = os.path.exists(gcn_save_dir)
    if not isExist:
        os.makedirs(gcn_save_dir)
        print("The new directory is created!")

    isExist = os.path.exists(belief_save_dir)
    if not isExist:
        os.makedirs(belief_save_dir)
        print("The new directory is created!")
    
    gcn_save_dir = gcn_save_dir+f'{space_name}_seed_{seed_num}.pt'
    belief_save_dir = belief_save_dir+f'{space_name}_seed_{seed_num}.pt'
    torch.save(GCN_model.state_dict(), gcn_save_dir)
    torch.save(beliefs, belief_save_dir)
    print('Graph model saved')
        
    metric = Metrics()
    val_acc, val_pre, val_rec, val_f1, val_ba, val_auc = metric(GCN_model, data, val_p_idx, val_n_idx)
    test_acc, test_pre, test_rec, test_f1, test_ba, test_auc = metric(GCN_model, data, test_p_idx, test_n_idx)
    
    embedding_save_dir = f'/data/project/joebrother/pu_learning/Results/{save_dir}/GRAB/embedding_vectors/'
    isExist = os.path.exists(embedding_save_dir)
    if not isExist:
        os.makedirs(embedding_save_dir)
    if save_embedding == True:
        vectors = GCN_model._embedding(data).detach().cpu()
        torch.save(vectors, embedding_save_dir + f'{space_name}_seed_{seed_num}.pt')
    
    perform_save_dir = f'/data/project/joebrother/pu_learning/Results/{save_dir}/GRAB/performance/'
    isExist = os.path.exists(perform_save_dir)
    if not isExist:
        os.makedirs(perform_save_dir)
        f = open(perform_save_dir + f'{space_name}_val_performances.csv', 'w', newline='')
        wr = csv.writer(f)
        wr.writerow(['Seed','AUC','Accuracy','Balanced accuracy','F1 score','Precision','Recall'])
        f.close()

        f = open(perform_save_dir + f'{space_name}_test_performances.csv', 'w', newline='')
        wr = csv.writer(f)
        wr.writerow(['Seed','AUC','Accuracy','Balanced accuracy','F1 score','Precision','Recall'])
        f.close()
            
    f = open(perform_save_dir + f'{space_name}_val_performances.csv', 'a', newline='')
    wr = csv.writer(f)
    wr.writerow([seed_num, val_auc, val_acc, val_ba, val_f1, val_pre, val_rec])
    f.close()

    f = open(perform_save_dir + f'{space_name}_test_performances.csv', 'a', newline='')
    wr = csv.writer(f)
    wr.writerow([seed_num, test_auc, test_acc, test_ba, test_f1, test_pre, test_rec])
    f.close()
    
def train(model, data, beliefs, p_node_index, u_node_index, num_epoches, optimizer, device, class_prior=None):     
    for epoch in range(num_epoches):
        model.train()
        output = model(data)
        loss = get_loss(output, beliefs, p_node_index, u_node_index, device, class_prior)
        optimizer.zero_grad()
        loss.backward()
        optimizer.step()
    return loss.item()