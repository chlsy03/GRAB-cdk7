import numpy as np
import torch
from torch import nn
import torch.nn.functional as F
from sklearn import metrics

class Metrics(nn.Module):
    def __init__(self):
        super().__init__()

    def forward(self, model, data, test_p, test_n):
        model.eval()
        output = model(data)
        
        p_true_y = p_true(test_p)
        n_true_y = n_true(test_n)
        true_y = torch.cat([p_true_y, n_true_y])
        
        test = torch.cat([test_p, test_n])
        pred = output[test].detach().cpu()
        
        pred_y_pro = F.softmax(pred, dim=1)
        
        fpr, tpr, thresholds = metrics.roc_curve(true_y, pred_y_pro[:,1], pos_label=1)
        auc = metrics.auc(fpr, tpr)
        
        optimal_idx = np.argmax(tpr-fpr)
        optimal_threshold = thresholds[optimal_idx]
        
        pred_y = (pred_y_pro[:,1] > optimal_threshold) * 1

        accuracy = metrics.accuracy_score(true_y, pred_y)
        precision = metrics.precision_score(true_y, pred_y, pos_label=1)
        recall = metrics.recall_score(true_y, pred_y, pos_label=1)
        f1 = metrics.f1_score(true_y, pred_y, pos_label=1)
        ba = metrics.balanced_accuracy_score(true_y, pred_y)

        return accuracy, precision, recall, f1, ba, auc
    
class Metrics_old(nn.Module):
    def __init__(self):
        super().__init__()

    def forward(self, model, data, test_p, test_n):
        model.eval()
        output = model(data)
        
        p_true_y = p_true(test_p)
        n_true_y = n_true(test_n)
        true_y = torch.cat([p_true_y, n_true_y])
        
        test = torch.cat([test_p, test_n])
        pred = output[test].detach().cpu()
        
        pred_y_pro = F.softmax(pred, dim=1)
        
        fpr, tpr, thresholds = metrics.roc_curve(true_y, pred_y_pro[:,0], pos_label=0)
        auc = metrics.auc(fpr, tpr)
        
        optimal_idx = np.argmax(tpr-fpr)
        optimal_threshold = thresholds[optimal_idx]
        
        pred_y = (pred_y_pro[:,0] < 0.5) * 1

        accuracy = metrics.accuracy_score(true_y, pred_y)
        precision = metrics.precision_score(true_y, pred_y, pos_label=0)
        recall = metrics.recall_score(true_y, pred_y, pos_label=0)
        f1 = metrics.f1_score(true_y, pred_y, pos_label=0)
        ba = metrics.balanced_accuracy_score(true_y, pred_y)

        return accuracy, precision, recall, f1, ba, auc
    
def p_true(positive_node_index):
    return torch.ones(len(positive_node_index), dtype=torch.int64)

def n_true(negative_node_index):
    return torch.zeros(len(negative_node_index), dtype=torch.int64)